#ifndef MAINCOMPONENT_H_INCLUDED
#define MAINCOMPONENT_H_INCLUDED

#include "../JuceLibraryCode/JuceHeader.h"

class MainContentComponent   :  public Component,
                                public Button::Listener,
                                public ComboBox::Listener
{
public:
    MainContentComponent()
    {
        setSize (400, 500);

        initializeGUI();
        
        formatManager.registerBasicFormats();
    }

    ~MainContentComponent()
    {
        shutdownComponent();
    }

    
    void openButtonClicked()
    {
        if(chooser->browseForMultipleFilesToOpen())
        {
            openedFiles = &chooser->getResults();
            queuedFileCount.setText(String(openedFiles->size()) + " files queued for converting");
        }
    }
    
    void stereoToggleClicked(Button* button)
    {
        if(button->getToggleState())
        {
            numChannels = 2;
        }
        else
        {
            numChannels = 1;
        }
    }
    
    void convertButtonClicked()
    {
        ScopedPointer<WavAudioFormat> wav = new WavAudioFormat();
        
        for (const File outFile : *openedFiles)
        {
            ScopedPointer<AudioFormatReader> reader = formatManager.createReaderFor(outFile);
            
            String outputPath = outFile.getFullPathName().trimCharactersAtEnd(".wav") += "_"+String(newSampleRate)+".wav"; //get original path and add new SR tag
            File outputFile = File(outputPath);
            outputFile.deleteFile(); //safecheck to delete the existing file before writing new one
            
            ScopedPointer<FileOutputStream> outStream (outputFile.createOutputStream());
            ScopedPointer<AudioFormatWriter> writer (wav->createWriterFor(outStream, newSampleRate, numChannels, newBitRate, reader->metadataValues, 0));
            
            if(reader != nullptr)
            {
                ScopedPointer<AudioFormatReaderSource> readerSource = new AudioFormatReaderSource(reader, true); //Source that shoves read file into a big buffer
                
                AudioTransportSource resamplingSource; //Source which converts SR under the hood
                resamplingSource.setSource(readerSource, 0, nullptr, reader->sampleRate);
                resamplingSource.prepareToPlay(2048, newSampleRate);
                resamplingSource.start();
                
                writer->writeFromAudioSource(resamplingSource, resamplingSource.getTotalLength());
            }
            outStream.release(); //reset output stream for next file
            reader.release(); //reset sample reader for next file
            
            if(deleteOriginalsToggle.getToggleState())
            {
                outFile.deleteFile();
            }
            
            outputFile.revealToUser(); //open containing folder with converted files
        }
    };
    
    void shutdownComponent()
    {
    }

//===GUI===============================================================================================================
    void initializeGUI()
    {
        //OPEN BUTTON
        addAndMakeVisible(&openButton);
        openButton.setButtonText("Open...");
        openButton.addListener(this);
        
        //ITEM COUNT LABEL
        addAndMakeVisible(&queuedFileCount);
        queuedFileCount.setEnabled(true);
        
        //SAMPLE RATE COMBOBOX
        addAndMakeVisible(&sampleRateMenu);
        sampleRateMenu.setEnabled(true);
        sampleRateMenu.addListener(this);
        sampleRateMenu.setText("Sample Rate");
        sampleRateMenu.addItem("44,100Hz", 44100);
        sampleRateMenu.addItem("48,000Hz", 48000);
        sampleRateMenu.addItem("88,200Hz", 88200);
        sampleRateMenu.addItem("96,000Hz", 96000);
        sampleRateMenu.addItem("192,000Hz", 192000);
        
        //BIT RATE COMBOBOX
        addAndMakeVisible(&bitRateMenu);
        bitRateMenu.setEnabled(true);
        bitRateMenu.addListener(this);
        bitRateMenu.setText("Bit Rate");
        bitRateMenu.addItem("16bit", 16);
        bitRateMenu.addItem("24bit", 24);
        bitRateMenu.addItem("32bit", 32);
        
        //STEREO TOGGLE
        addAndMakeVisible(&stereoToggle);
        stereoToggle.setEnabled(true);
        stereoToggle.addListener(this);
        stereoToggle.setButtonText("Stereo");
        stereoToggle.setToggleState(true, juce::NotificationType::sendNotification);
        
        //DELETE ORIGINALS TOGGLE
        addAndMakeVisible(&deleteOriginalsToggle);
        deleteOriginalsToggle.setEnabled(true);
        deleteOriginalsToggle.addListener(this);
        deleteOriginalsToggle.setButtonText("Delete original files");
        deleteOriginalsToggle.setToggleState(false, juce::NotificationType::dontSendNotification);
        
        //INSTRUCTION LABEL
        addAndMakeVisible(instructionOne);
        instructionOne.setEnabled(true);
        instructionOne.setText("Files will be saved in source directory, adding '_newSR' at the end", juce::NotificationType::dontSendNotification);
        
        //CONVERT BUTTON
        addAndMakeVisible(&convertButton);
        convertButton.setButtonText("Convert");
        convertButton.addListener(this);
        convertButton.setEnabled(false);
    }
    
    void paint (Graphics& g) override
    {
        g.fillAll (Colours::aquamarine);
    }
    
    void resized() override
    {
        openButton.setBounds((getWidth()/2)-(getWidth()/5/2), 20, getWidth()/5, getWidth()/5);
        instructionOne.setBounds(10, getHeight()/4*2-30, getWidth() - 20, 20);
        queuedFileCount.setBounds(10, getHeight()/4*2, getWidth() - 20, 20);
        convertButton.setBounds((getWidth()/2)-(getWidth()/3/2), getHeight()/4*3, getWidth()/3, getWidth()/5);
        
        sampleRateMenu.setBounds((getWidth()/11), getHeight()/4, 120, 30);
        bitRateMenu.setBounds((getWidth()/10*5), getHeight()/4, 100, 30);
        stereoToggle.setBounds((getWidth()/10*8), getHeight()/4, 100, 30);
        deleteOriginalsToggle.setBounds((getWidth()/12), getHeight()/3, 150, 30);
    }
    
    void buttonClicked(Button* button) override
    {
        if (button == &openButton) openButtonClicked();
        if (button == &convertButton) convertButtonClicked();
        if (button == &stereoToggle) stereoToggleClicked(button);
    }
    
    void comboBoxChanged (ComboBox* comboBoxThatHasChanged) override //listens for dropdown menu changes and applies them accordingly
    {
        if (comboBoxThatHasChanged == &sampleRateMenu)
        {
            newSampleRate = comboBoxThatHasChanged->getItemId(comboBoxThatHasChanged->getSelectedItemIndex());
            instructionOne.setText("Files will be saved in source directory, adding '_"+String(newSampleRate)+"' at the end", juce::NotificationType::dontSendNotification);
        }
        if (comboBoxThatHasChanged == &bitRateMenu) newBitRate = comboBoxThatHasChanged->getItemId(comboBoxThatHasChanged->getSelectedItemIndex());
        
        if(sampleRateMenu.getSelectedItemIndex() != -1 && bitRateMenu.getSelectedItemIndex() != -1 && openedFiles != NULL)
        {
           convertButton.setEnabled(true); //enables CONVERT button only if SR, bitrate and files are selected
        }
    }
//=====================================================================================================================
    
    
private:
        TextButton openButton;
        TextEditor queuedFileCount;
        TextButton convertButton;
        Label instructionOne;
        ComboBox sampleRateMenu;
        ComboBox bitRateMenu;
        ToggleButton stereoToggle;
        ToggleButton deleteOriginalsToggle;
    
        AudioFormatManager formatManager;
        ScopedPointer<FileChooser> chooser = new FileChooser("Select a Wave file to convert...", File::nonexistent, "*.wav");
        const Array<File>* openedFiles;
    
        int newSampleRate;
        int newBitRate;
        int numChannels;
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainContentComponent)
};


// (This function is called by the app startup code to create our main component)
Component* createMainContentComponent()     { return new MainContentComponent(); }

#endif  // MAINCOMPONENT_H_INCLUDED
