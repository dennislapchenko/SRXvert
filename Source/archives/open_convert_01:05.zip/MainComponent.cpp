#ifndef MAINCOMPONENT_H_INCLUDED
#define MAINCOMPONENT_H_INCLUDED

#include "../JuceLibraryCode/JuceHeader.h"

class MainContentComponent   :  public AudioAppComponent,
                                public Button::Listener
{
public:
    //==============================================================================
    MainContentComponent()
    {
        setSize (400, 500);

        addAndMakeVisible(&openButton);
        openButton.setButtonText("Open...");
        openButton.addListener(this);
        
        addAndMakeVisible(&sampleRateInput);
        sampleRateInput.setEnabled(true);

        addAndMakeVisible(&convertButton);
        convertButton.setButtonText("Convert");
        convertButton.addListener(this);
        convertButton.setEnabled(false);
        
        formatManager.registerBasicFormats();
        
        setAudioChannels (2, 2);
    }

    ~MainContentComponent()
    {
        shutdownAudio();
    }

    void prepareToPlay (int samplesPerBlockExpected, double sampleRate) override
    {
        resamplingSource.prepareToPlay(samplesPerBlockExpected, sampleRate);
    }

    void getNextAudioBlock (const AudioSourceChannelInfo& bufferToFill) override
    {
        if(rdrSource == nullptr)
        {
            bufferToFill.clearActiveBufferRegion();
            return;
        }
        resamplingSource.getNextAudioBlock(bufferToFill);
    }

    void releaseResources() override
    {
        // This will be called when the audio device stops
        resamplingSource.releaseResources();
        rdrSource->releaseResources();
    }

    //===GUI===
    void paint (Graphics& g) override
    {
        g.fillAll (Colours::black);
    }

    void resized() override
    {
        openButton.setBounds((getWidth()/2)-(getWidth()/5/2), getHeight()/5, getWidth()/5, getWidth()/5);
        sampleRateInput.setBounds(10, getHeight()/4*2, getWidth() - 20, 20);
        convertButton.setBounds((getWidth()/2)-(getWidth()/3/2), getHeight()/4*3, getWidth()/3, getWidth()/5);
    }
    
    void buttonClicked(Button* button) override
    {
        if (button == &openButton) openButtonClicked();
        if (button == &convertButton) convertButtonClicked();
    }
    //=========
    
    void openButtonClicked()
    {
        FileChooser chooser ("Select a Wave file to convert...",
                                File::nonexistent,
                                "*.wav");
        if(chooser.browseForFileToOpen())
        {
            File file (chooser.getResult());
            outputPath = file.getFullPathName().trimCharactersAtEnd(".wav") += "_48000.wav";
            sampleRateInput.setText(outputPath);
            
            reader = formatManager.createReaderFor(file);

            if(reader != nullptr)
            {
                sampleRate = reader->sampleRate;
                convertButton.setEnabled(true);
            }
        }
    }
    
    void convertButtonClicked()
    {
        File outputFile = File(outputPath);
        outputFile.deleteFile();
        
        ScopedPointer<WavAudioFormat> wav = new WavAudioFormat();
        ScopedPointer<FileOutputStream> outStream (outputFile.createOutputStream());
        ScopedPointer<AudioFormatWriter> writer (wav->createWriterFor(outStream, 48000, 2, 16, new StringPairArray(), 0));
        
        if(writer != nullptr)
        {
            ScopedPointer<AudioFormatReaderSource> readerSource = new AudioFormatReaderSource(reader, true);
            rdrSource = readerSource.release();
            
            resamplingSource.setSource(rdrSource, 0, nullptr, sampleRate);
            resamplingSource.prepareToPlay(2048, 48000);
            resamplingSource.start();
           
            writer->writeFromAudioSource(resamplingSource, resamplingSource.getTotalLength());
        }
        outStream.release();
    };
    
    void shutdownAudio()
    {
    }
    
    
private:
        TextButton openButton;
        TextEditor sampleRateInput;
        TextButton convertButton;
    
        AudioFormatManager formatManager;

        ScopedPointer<AudioFormatReader> reader;
        ScopedPointer<AudioFormatReaderSource> rdrSource;
        AudioTransportSource resamplingSource;
        String outputPath;
        double sampleRate;
    
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainContentComponent)
};


// (This function is called by the app startup code to create our main component)
Component* createMainContentComponent()     { return new MainContentComponent(); }

#endif  // MAINCOMPONENT_H_INCLUDED
