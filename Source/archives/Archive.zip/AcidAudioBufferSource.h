//
//  AcidAudioBufferSource.hpp
//  SRXvert
//
//  Created by Dennis Lapchenko on 04/05/2016.
//
//

#ifndef AcidAudioBufferSource_h
#define AcidAudioBufferSource_h

#include "../JuceLibraryCode/JuceHeader.h"
#include "AcidAudioBuffer.h"

#endif /* AcidAudioBufferSource_h */

namespace AcidR
{
    class AcidAudioBufferSource : public PositionableAudioSource
    {
    private:
        int _position;
        int _start;
        bool _repeat;
        
        
    public:
        AcidAudioBufferSource(AcidAudioBuffer *buffer);
        
        ~AcidAudioBufferSource();
        
        void getNextAudioBlock(const AudioSourceChannelInfo &info);
        
        void prepareToPlay(int, double);
        
        void releaseResources();
        
        void setNextReadPosition(long long newPosition);
        
        long long getNextReadPosition() const;
        
        long long getTotalLength() const;
        
        bool isLooping() const;
        
        void setLooping(bool shouldLoop);
        
        void setBuffer(AcidAudioBuffer *buffer);
        
        AcidAudioBuffer *_buffer;
    };
}